package com.nebula.stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.*;
import stream.nebula.exceptions.RESTExecption;
import stream.nebula.runtime.NebulaStreamRuntime;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//This test will validate, if the the REST EPs of the StreamCatalog are working without throwing RESTExceptions
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class StreamCatalogTest {
    private static NebulaStreamRuntime nebulaStreamRuntime;
    @BeforeAll
    public static void init() throws IOException {
        nebulaStreamRuntime = NebulaStreamRuntime.getRuntime();
        nebulaStreamRuntime.getConfig().setHost("localhost")
                .setPort("8081");
        Assertions.assertTrue(nebulaStreamRuntime.checkConnection());
    }

    //Test for adding a logical Stream to NES
    @Test
    @Order(0)
    public void addLogicalStream() throws RESTExecption, IOException {
        String streamname = "TestLogiStream";
        String schema = "Schema::create()->addField(\"test\",INT32);";

        boolean added = nebulaStreamRuntime.addLogicalStream(streamname, schema);
        Assertions.assertTrue(added);
    }

    //Test for getting the logical StreamCatalog from NES
    @Test
    @Order(1)
    public void getStreamCatalog() throws RESTExecption, IOException {
        List<String> StreamCatalog = nebulaStreamRuntime.getAvailableLogicalStreams();

        String expectedCatalog = "[TestLogiStream, exdra, default_logical]";
        Assertions.assertEquals(expectedCatalog, StreamCatalog.toString());
    }

    //Test for updating a logical Stream with another schema
    @Test
    @Order(2)
    public void updateLogicalStream() throws RESTExecption, IOException {
        String streamname = "TestLogiStream";
        String schema = "Schema::create()->addField(\"anothertest\",INT32);";

        boolean updated = nebulaStreamRuntime.updateLogicalStream(streamname, schema);
        Assertions.assertTrue(updated);
    }

    //Test of deleting a logical Stream from NES
    @Test
    @Order(3)
    public void deleteLogicalStream() throws RESTExecption, IOException {
        String streamname = "TestLogiStream";
        boolean deleted = nebulaStreamRuntime.deleteLogicalStream(streamname);
        Assertions.assertTrue(deleted);

        List<String> StreamCatalog = nebulaStreamRuntime.getAvailableLogicalStreams();
        String expectedCatalog = "[exdra, default_logical]";
        Assertions.assertEquals(expectedCatalog, StreamCatalog.toString());
    }

    //Test for getting the physical StreamCatalog from NES
    @Test
    @Order(4)
    public void getPhysicalStreamCatalog() throws RESTExecption, IOException, InterruptedException {
        Thread.sleep(5000); //Time for docker to setup NES, because it could fail, when tested early
        ArrayList<String> physicalStreamOfDefaultLogical = nebulaStreamRuntime.getAvailablePhysicalStreamsOfLogicalStream("default_logical");

        String expectedCatalog = "[physicalName=default_physical logicalStreamName=default_logical sourceType=DefaultSource on node=2]";
        Assertions.assertEquals(expectedCatalog, physicalStreamOfDefaultLogical.toString());
    }

}
