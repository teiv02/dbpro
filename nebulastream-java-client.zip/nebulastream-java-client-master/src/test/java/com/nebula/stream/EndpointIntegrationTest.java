package com.nebula.stream;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.*;
import stream.nebula.exceptions.EmptyFieldException;
import stream.nebula.exceptions.RESTExecption;
import stream.nebula.operators.Aggregation;
import stream.nebula.operators.EventTime;
import stream.nebula.operators.TimeMeasure;
import stream.nebula.operators.sink.PrintSink;
import stream.nebula.operators.windowdefinition.TumblingWindow;
import stream.nebula.queryinterface.Query;
import stream.nebula.runtime.NebulaStreamRuntime;
import java.io.IOException;

//Tests if the REST EPs of the topology, queryPlan and ExecutionPlan are working without throwing RESTException
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class EndpointIntegrationTest {
    private static NebulaStreamRuntime nebulaStreamRuntime;
    private static int queryId;
    @BeforeAll
    public static void init() throws IOException, EmptyFieldException, RESTExecption {
        nebulaStreamRuntime = NebulaStreamRuntime.getRuntime();
        nebulaStreamRuntime.getConfig().setHost("localhost")
                .setPort("8081");
        Assertions.assertTrue(nebulaStreamRuntime.checkConnection());

        //To be sure, that a working Query gets submitted first, for the executionplan and queryplan
        Query tumblingWindowQuery = new Query();
        tumblingWindowQuery.from("exdra")
                .window(TumblingWindow.of(new EventTime("metadata_generated"), TimeMeasure.milliseconds(10)), Aggregation.sum("features_properties_capacity"))
                .sink(new PrintSink());
        queryId = nebulaStreamRuntime.executeQuery(tumblingWindowQuery.generateCppCode(), "BottomUp");
        Assertions.assertNotNull(queryId);
    }

    //Tests the retrieving of the topology
    @Order(0)
    @Test
    public void getTopologyTest() throws RESTExecption, IOException {
        HttpGet request = new HttpGet("http://" + nebulaStreamRuntime.getConfig().getHost() + ":" + nebulaStreamRuntime.getConfig().getPort() + "/v1/nes/topology");
        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = httpClient.execute(request);

        if (response.getStatusLine().getStatusCode() == 200) {
            JSONObject responseJson = new JSONObject(EntityUtils.toString(response.getEntity()));
            Assertions.assertNotNull(responseJson);
        } else {
            throw new RESTExecption(response.getStatusLine().getStatusCode());
        }
    }

    //Tests the retrieving of the queryPlan to a specific queryId
    @Order(1)
    @Test
    public void getQueryPlanTest() throws RESTExecption, IOException {
        HttpGet request = new HttpGet("http://" + nebulaStreamRuntime.getConfig().getHost() + ":" + nebulaStreamRuntime.getConfig().getPort() + "/v1/nes/query/query-plan?queryId=" + queryId);
        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = httpClient.execute(request);

        if (response.getStatusLine().getStatusCode() == 200) {
            JSONObject responseJson = new JSONObject(EntityUtils.toString(response.getEntity()));
            Assertions.assertNotNull(responseJson);
        } else {
            throw new RESTExecption(response.getStatusLine().getStatusCode());
        }
    }

    //Tests the retrieving of the executionPlan to a specific queryId
    @Order(2)
    @Test
    public void getExecutionPlanTest() throws RESTExecption, IOException {
        HttpGet request = new HttpGet("http://" + nebulaStreamRuntime.getConfig().getHost() + ":" + nebulaStreamRuntime.getConfig().getPort() + "/v1/nes/query/execution-plan?queryId=" + queryId);
        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = httpClient.execute(request);

        if (response.getStatusLine().getStatusCode() == 200) {
            JSONObject responseJson = new JSONObject(EntityUtils.toString(response.getEntity()));
            Assertions.assertNotNull(responseJson);
        } else {
            throw new RESTExecption(response.getStatusLine().getStatusCode());
        }
    }
}
