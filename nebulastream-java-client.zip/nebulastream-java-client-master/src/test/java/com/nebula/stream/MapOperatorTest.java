package com.nebula.stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import stream.nebula.exceptions.EmptyFieldException;
import stream.nebula.operators.Map;
import stream.nebula.operators.Operation;
import stream.nebula.queryinterface.Query;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class MapOperatorTest {
    @Test
    public void mapOnFieldName() throws EmptyFieldException {
        Query query;

        query = new Query();
        query.from("defaultLogical").map(Map.onField("value1").assign(Operation.add("value1","value2")));

        Assertions.assertEquals("Query::from(\"defaultLogical\").map(Attribute(\"value1\") = Attribute(\"value1\") + Attribute(\"value2\"));"
                , query.generateCppCode());
    }

    @Test
    public void mapOperationWithConstantAssignment() throws EmptyFieldException {
        Query query;

        query = new Query();
        query.from("defaultLogical").map(Map.onField("value1").assign(Operation.constant(10)));

        Assertions.assertEquals("Query::from(\"defaultLogical\").map(Attribute(\"value1\") = 10);"
                , query.generateCppCode());
    }

    @Test
    public void mapWithEmptyFieldThrowEmptyFieldException() {
        Exception exception = assertThrows(EmptyFieldException.class, () -> {
            Query query;

            query = new Query();
            query.from("defaultLogical").map(Map.onField("").assign(Operation.add("value1","value2")));

            query.generateCppCode();
        });

        String expectedMessage = "Map field cannot be empty";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void mapOperationOnNewField() throws EmptyFieldException {
        Query query;

        query = new Query();
        query.from("defaultLogical").map(Map.onField("newfield").assign(Operation.add("value1","value2")));

        Assertions.assertEquals("Query::from(\"defaultLogical\").map(Attribute(\"newfield\") = Attribute(\"value1\") + Attribute(\"value2\"));"
                , query.generateCppCode());
    }

    @Test
    public void mapOperationOperators() throws EmptyFieldException {
        Query query;

        query = new Query();
        query.from("defaultLogical").map(Map.onField("newfield").assign(Operation.add("value1","value2")));
        Assertions.assertEquals("Query::from(\"defaultLogical\").map(Attribute(\"newfield\") = Attribute(\"value1\") + Attribute(\"value2\"));"
                , query.generateCppCode());

        query = new Query();
        query.from("defaultLogical").map(Map.onField("newfield").assign(Operation.substract("value1","value2")));
        Assertions.assertEquals("Query::from(\"defaultLogical\").map(Attribute(\"newfield\") = Attribute(\"value1\") - Attribute(\"value2\"));"
                , query.generateCppCode());

        query = new Query();
        query.from("defaultLogical").map(Map.onField("newfield").assign(Operation.multiply("value1","value2")));
        Assertions.assertEquals("Query::from(\"defaultLogical\").map(Attribute(\"newfield\") = Attribute(\"value1\") * Attribute(\"value2\"));"
                , query.generateCppCode());

        query = new Query();
        query.from("defaultLogical").map(Map.onField("newfield").assign(Operation.divide("value1","value2")));
        Assertions.assertEquals("Query::from(\"defaultLogical\").map(Attribute(\"newfield\") = Attribute(\"value1\") / Attribute(\"value2\"));"
                , query.generateCppCode());
    }
}
