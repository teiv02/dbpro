package com.nebula.stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import stream.nebula.model.query.QueryCatalogEntry;
import stream.nebula.operators.*;
import stream.nebula.operators.sink.*;
import stream.nebula.queryinterface.Query;
import stream.nebula.runtime.NebulaStreamRuntime;
import java.io.IOException;
import java.util.ArrayList;

//This test will validate, if the the REST EPs of the QueryCatalog are working without throwing RESTExceptions
public class QueryCatalogTest {
    private static NebulaStreamRuntime nebulaStreamRuntime;
    @BeforeAll
    public static void init() throws IOException {
        nebulaStreamRuntime = NebulaStreamRuntime.getRuntime();
        nebulaStreamRuntime.getConfig().setHost("localhost")
                .setPort("8081");
        Assertions.assertTrue(nebulaStreamRuntime.checkConnection());
    }

    //Test for getting the QueryCatalog from NES
    @Test
    public void getQueryCatalog() throws Exception {
        String defaultLogical = "default_logical";

        Query filterWithOnePredicateQuery = new Query();
        filterWithOnePredicateQuery.from(defaultLogical)
                .filter(Predicate.onField("id").greaterThan(42))
                .sink(new PrintSink());
        Integer filterWithOnePredicateQueryId = nebulaStreamRuntime.executeQuery(filterWithOnePredicateQuery.generateCppCode(), "BottomUp");

        Query filterWithMultiplePredicateQuery = new Query();
        filterWithMultiplePredicateQuery.from(defaultLogical)
                .filter(Predicate.onField("id").greaterThan(100).and(Predicate.onField("id").greaterThan(200)))
                .sink(new PrintSink());
        Integer filterWithMultiplePredicateQueryId = nebulaStreamRuntime.executeQuery(filterWithMultiplePredicateQuery.generateCppCode(), "BottomUp");

        ArrayList<QueryCatalogEntry> catalog = nebulaStreamRuntime.getAllRegisteredQueries();

        // Test to assert the catalog length
        Assertions.assertNotEquals(0, catalog.size());

        // Tests if submitted queries are in the QueryCatalog now
        QueryCatalogEntry firstQuery = catalog.get(filterWithOnePredicateQueryId-1);
        QueryCatalogEntry secondQuery = catalog.get(filterWithMultiplePredicateQueryId-1);

        Assertions.assertEquals(firstQuery.getQueryId(), filterWithOnePredicateQueryId);
        Assertions.assertEquals(firstQuery.getQueryString(), filterWithOnePredicateQuery.generateCppCode());
        Assertions.assertEquals(secondQuery.getQueryId(), filterWithMultiplePredicateQueryId);
        Assertions.assertEquals(secondQuery.getQueryString(), filterWithMultiplePredicateQuery.generateCppCode());
    }

    //Test for getting the QueryCatalog to a specific status from NES
    @Test
    public void getQueryCatalogWithStatus() throws Exception {
        String defaultLogical = "default_logical";
        boolean found = false;

        /*Test querys to fill the Catalog*/
        Query filterWithOnePredicateQuery = new Query();
        filterWithOnePredicateQuery.from(defaultLogical)
                .filter(Predicate.onField("id").greaterThan(42))
                .sink(new PrintSink());
        Integer filterWithOnePredicateQueryId = nebulaStreamRuntime.executeQuery(filterWithOnePredicateQuery.generateCppCode(), "BottomUp");

        Query filterWithMultiplePredicateQuery = new Query();
        filterWithMultiplePredicateQuery.from(defaultLogical)
                .filter(Predicate.onField("id").greaterThan(100).and(Predicate.onField("id").greaterThan(200)))
                .sink(new PrintSink());
        Integer filterWithMultiplePredicateQueryId = nebulaStreamRuntime.executeQuery(filterWithMultiplePredicateQuery.generateCppCode(), "BottomUp");

        Query q1 = new Query();
        q1.from("exdra").sink(new PrintSink());
        Integer q1Id = nebulaStreamRuntime.executeQuery(q1.generateCppCode(), "BottomUp");

        /*Getting all stats of the catalog hopefully without REST Exception*/
        ArrayList<QueryCatalogEntry> catalogRegistered = nebulaStreamRuntime.getRegisteredQueryWithStatus("Registered");
        ArrayList<QueryCatalogEntry> catalogScheduling = nebulaStreamRuntime.getRegisteredQueryWithStatus("Scheduling");
        ArrayList<QueryCatalogEntry> catalogRunning = nebulaStreamRuntime.getRegisteredQueryWithStatus("Running");
        ArrayList<QueryCatalogEntry> catalogFailed = nebulaStreamRuntime.getRegisteredQueryWithStatus("Failed");

        if (!catalogRegistered.isEmpty() || !catalogScheduling.isEmpty() || !catalogRunning.isEmpty() || !catalogFailed.isEmpty()) {
            found = true;
        }
        Assertions.assertTrue(found);
    }
}
