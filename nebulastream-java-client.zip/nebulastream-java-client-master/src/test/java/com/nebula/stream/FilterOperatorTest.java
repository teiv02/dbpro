package com.nebula.stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import stream.nebula.exceptions.EmptyFieldException;
import stream.nebula.operators.Predicate;
import stream.nebula.queryinterface.Query;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FilterOperatorTest {
    @Test
    public void filterPredicateGenerateCorrectOperatorInCppCode() throws Exception {
        Query query;

        query = new Query();
        query.from("defaultLogical")
                .filter(Predicate.onField("value").greaterThan(42));
        Assertions.assertEquals("Query::from(\"defaultLogical\").filter(Attribute(\"value\")>42);", query.generateCppCode());

        query = new Query();
        query.from("defaultLogical")
                .filter(Predicate.onField("value").greaterThanOrEqual(42));
        Assertions.assertEquals("Query::from(\"defaultLogical\").filter(Attribute(\"value\")>=42);", query.generateCppCode());

        query = new Query();
        query.from("defaultLogical")
                .filter(Predicate.onField("value").lessThan(42));
        Assertions.assertEquals("Query::from(\"defaultLogical\").filter(Attribute(\"value\")<42);", query.generateCppCode());

        query = new Query();
        query.from("defaultLogical")
                .filter(Predicate.onField("value").lessThanOrEqual(42));
        Assertions.assertEquals("Query::from(\"defaultLogical\").filter(Attribute(\"value\")<=42);", query.generateCppCode());

        query = new Query();
        query.from("defaultLogical")
                .filter(Predicate.onField("value").equal(42));
        Assertions.assertEquals("Query::from(\"defaultLogical\").filter(Attribute(\"value\")==42);", query.generateCppCode());
    }

    @Test
    public void filterPredicateWithEmptyFieldThrowEmptyFieldException() {
        Exception exception = assertThrows(EmptyFieldException.class, () -> {
            Query query;

            query = new Query();
            query.from("")
                    .filter(Predicate.onField("value").equal(42));
            query.generateCppCode();
        });

        String expectedMessage = "From field cannot be empty";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void multipleFilterPredicateWithAnd() throws EmptyFieldException {
        Query query;

        query = new Query();
        query.from("defaultLogical")
                .filter(Predicate.onField("value").greaterThan(100).and(Predicate.onField("value").lessThan(200)));
        Assertions.assertEquals("Query::from(\"defaultLogical\").filter(Attribute(\"value\")>100 && Attribute(\"value\")<200);"
                , query.generateCppCode());
    }

    @Test
    public void multipleFilterPredicateWithOr() throws EmptyFieldException {
        Query query;

        query = new Query();
        query.from("defaultLogical")
                .filter(Predicate.onField("value").greaterThan(100).or(Predicate.onField("value").lessThan(200)));
        Assertions.assertEquals("Query::from(\"defaultLogical\").filter(Attribute(\"value\")>100 || Attribute(\"value\")<200);"
                , query.generateCppCode());
    }
}
