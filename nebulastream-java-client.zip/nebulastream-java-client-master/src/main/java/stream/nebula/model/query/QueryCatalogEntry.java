package stream.nebula.model.query;

public class QueryCatalogEntry {
    Integer queryId;
    String queryStatus;
    String queryString;

    public QueryCatalogEntry(Integer queryId, String queryStatus, String queryString) {
        this.queryStatus = queryStatus;
        this.queryId = queryId;
        this.queryString = queryString;
    }

    public Integer getQueryId() {
        return queryId;
    }

    public void setQueryId(Integer queryId) {
        this.queryId = queryId;
    }

    public String getQueryStatus() {
        return queryStatus;
    }

    public void setQueryStatus(String queryStatus) {
        this.queryStatus = queryStatus;
    }

    public String getQueryString() {
        return queryString;
    }

    public void setQueryString(String queryString) {
        this.queryString = queryString;
    }
}
