package stream.nebula.operators.sink;

import stream.nebula.operators.Operator;

/**
 * The base class to represent NES sink
 */
public abstract class Sink extends Operator {

}
