package stream.nebula.operators;

public interface TimeCharacteristic {
    String generateCode();
}
