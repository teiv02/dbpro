package stream.nebula.operators;

public abstract class Operator {
    public abstract String getCppCode();
}
