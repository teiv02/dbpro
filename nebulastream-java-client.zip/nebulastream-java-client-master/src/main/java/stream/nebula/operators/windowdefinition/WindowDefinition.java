package stream.nebula.operators.windowdefinition;

public abstract class WindowDefinition {
    public abstract String toString();
}
