package jeromqtesting.playground;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;
import stream.nebula.operators.Map;
import stream.nebula.operators.Operation;
import stream.nebula.operators.Predicate;
import stream.nebula.operators.sink.PrintSink;
import stream.nebula.queryinterface.Query;
import stream.nebula.runtime.NebulaStreamRuntime;

public class zmq_new {
        public static void main(String[] args) throws Exception {
            try (ZContext context = new ZContext()) {

                ZMQ.Socket socket = context.createSocket(SocketType.REP);
                socket.bind("tcp://*:5555");


                NebulaStreamRuntime nebulaStreamRuntime = NebulaStreamRuntime.getRuntime();
                nebulaStreamRuntime.getConfig().setHost("localhost")
                        .setPort("8081");

                // Create an instance of Query that assign the d5 field with the value of d3*d4
                Query query = new Query().from("ysb")
                        .filter(Predicate.onField("user_id").greaterThanOrEqual(1).and(Predicate.onField("user_id").lessThan(10000)))
                        .map(Map.onField("d5").assign(Operation.multiply("d3","d4")))
                        .sink(new PrintSink());

                // Print out the generated C++ code
                System.out.println(query.generateCppCode());

                // Execute the query to NES system. Additionally print the response to get the query-id.
                //int response = nebulaStreamRuntime.executeQuery(query.generateCppCode(), "BottomUp");
                //System.out.println("RESPONSE:\n"+response);

            while (true) {
                byte[] reply = socket.recv(0);

                String response1 = "messaged received";
                socket.send(response1.getBytes(ZMQ.CHARSET), 0);

                System.out.println("Received " + ": [" + new String(reply, ZMQ.CHARSET) + "]");
            }


            }
        }

}
