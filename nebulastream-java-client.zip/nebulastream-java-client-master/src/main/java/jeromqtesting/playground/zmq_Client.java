package jeromqtesting.playground;

import org.zeromq.SocketType;
import org.zeromq.ZMQ;
import org.zeromq.ZContext;

import java.util.Scanner;

public class zmq_Client {
    public static void main(String[] args) throws Exception{
        try (ZContext context = new ZContext()) {
            System.out.println("Connecting to messaging service");

            ZMQ.Socket socket = context.createSocket(SocketType.REQ);
            socket.connect("tcp://localhost:5555");

            System.out.println("ready to send messages to server");

            System.out.println("Enter messages to send");

            while (true) {

                Scanner input = new Scanner(System.in);
                String userInput = input.nextLine();
                socket.send(userInput.getBytes(ZMQ.CHARSET), 0);

                byte[] reply = socket.recv(0);


                //System.out.println("Received " + ": [" + new String(reply, ZMQ.CHARSET) + "]");
            }
        }
    }
}