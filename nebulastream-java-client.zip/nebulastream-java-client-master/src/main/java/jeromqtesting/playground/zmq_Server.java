package jeromqtesting.playground;

import org.zeromq.SocketType;
import org.zeromq.ZMQ;
import org.zeromq.ZContext;
import stream.nebula.operators.Map;
import stream.nebula.operators.Operation;
import stream.nebula.operators.Predicate;
import stream.nebula.operators.sink.PrintSink;
import stream.nebula.queryinterface.Query;
import stream.nebula.runtime.NebulaStreamRuntime;

public class zmq_Server {
    public static void main(String[] args) throws Exception {
        try (ZContext context = new ZContext()) {
            //  Socket to talk to clients

            ZMQ.Socket socket = context.createSocket(SocketType.REP);
            socket.bind("tcp://*:5555");

            System.out.println("Server up and running");
            System.out.println("waiting for incoming messages");


            while (true) {
                byte[] reply = socket.recv(0);

                String response = "messaged received";
                socket.send(response.getBytes(ZMQ.CHARSET), 0);

                System.out.println("Received " + ": [" + new String(reply, ZMQ.CHARSET) + "]");
            }


        }
    }
}