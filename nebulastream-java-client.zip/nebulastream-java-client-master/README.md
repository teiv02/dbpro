# nebulastream-java-client
This project provides the java client for building and submitting jobs to NebulaStream project 
